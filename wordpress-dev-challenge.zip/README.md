<p align="center">
  <a href='https://weremote.net'>
    <img src="https://weremote.net/wp-content/uploads/2021/04/Logo-WR.svg" width="300" />
  </a>
</p>
<br />


## Descripción
Desafios descritos en: (https://mcontigo.notion.site/Instrucciones-prueba-WordPress-0ab955afeefa428c9b25b74c221f2f46)

## --Author Quotes-- 
  ## Shortcode -> [mc-citacion] / [mc-citacion post_quote_id = "POST_ID"]

## --BadLinks Scanner-- 
  ## Menu Element => BadLinks Scanner
  ## (php-curl extention required)

Plugin developed and tested in WP6